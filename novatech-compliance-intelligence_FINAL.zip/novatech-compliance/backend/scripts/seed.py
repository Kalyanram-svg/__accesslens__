"""Reset the database and load the NovaTech demo dataset.

    python -m scripts.seed            # uses DATABASE_URL
"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.database.init import reset_schema  # noqa: E402
from app.database.session import SessionLocal, engine  # noqa: E402
from app.seed.seeder import seed  # noqa: E402

if __name__ == "__main__":
    t0 = time.time()
    reset_schema(engine)
    with SessionLocal() as db:
        out = seed(db)
    print(f"Seeded in {time.time() - t0:.1f}s:", out)
